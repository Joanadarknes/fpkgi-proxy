# Loja PS4

Site estatico para GitHub Pages.

Arquivos principais:

- `index.html`: interface da loja/catalogo.
- `GAMES_format.json`: catalogo carregado pela loja.
- `gamepad-controller.js`: suporte ao controle.
- `manifest.json` e `service-worker.js`: suporte PWA/cache.

No GitHub, publique usando:

- Source: `Deploy from a branch`
- Branch: `main`
- Folder: `/docs`
